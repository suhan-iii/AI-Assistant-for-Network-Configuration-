# AutoNet Config Backend

This is the FastAPI backend for AutoNet Config project.

## Endpoints
- POST /generate-config
  - Input: JSON { "command": "create vlan for Sales" }
  - Output: JSON { "config": "<generated config>" }

## Setup
1. pip install -r requirements.txt
2. python main.py
3. Access API at http://127.0.0.1:8000
