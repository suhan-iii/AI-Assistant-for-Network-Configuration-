from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from parser import parse_instruction

app = FastAPI()

class ConfigRequest(BaseModel):
    command: str

@app.post("/generate-config")
async def generate_config(request: ConfigRequest):
    try:
        config = parse_instruction(request.command)
        return {"config": config}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)