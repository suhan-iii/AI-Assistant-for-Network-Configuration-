def parse_instruction(command: str) -> str:
    # Simple example parsing logic, can be expanded with NLP
    if 'sales' in command.lower():
        return open('configs/vlan_sales.cfg').read()
    elif 'hr' in command.lower():
        return open('configs/vlan_hr.cfg').read()
    else:
        return "! Command not recognized" 