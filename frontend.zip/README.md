# AutoNet Config Frontend (Flutter)

This is the **Flutter frontend** for the AutoNet Config project.  
It connects with the FastAPI backend to generate Cisco IOS-style configs from natural language inputs.

## 📌 Current Features
- Input VLAN name and IP range
- Generate config (API integration WIP)
- UI components for login/signup (placeholders)

## 🚀 Setup
```bash
cd frontend
flutter pub get
flutter run
```

## 🔮 Future Plans
- Authentication (login/signup)
- Config history
- Polished UI design
