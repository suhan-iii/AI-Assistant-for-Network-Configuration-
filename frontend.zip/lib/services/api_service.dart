import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static const String baseUrl = "http://127.0.0.1:8000";

  static Future<String> generateConfig(String vlanName, String ipRange) async {
    final response = await http.post(
      Uri.parse("$baseUrl/generate-config/"),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"vlan_name": vlanName, "ip_range": ipRange}),
    );

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data["generated_config"];
    } else {
      throw Exception("Failed to generate config");
    }
  }
}