import 'package:flutter/material.dart';
import '../widgets/custom_button.dart';
import '../widgets/custom_input.dart';

class HomeScreen extends StatelessWidget {
  final TextEditingController vlanController = TextEditingController();
  final TextEditingController ipController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("AutoNet Config")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            CustomInput(controller: vlanController, hintText: "Enter VLAN Name"),
            SizedBox(height: 12),
            CustomInput(controller: ipController, hintText: "Enter IP Range"),
            SizedBox(height: 20),
            CustomButton(
              text: "Generate Config",
              onPressed: () {
                // TODO: Call API service
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text("Generating config...")),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}