import 'package:flutter/material.dart';

const kPrimaryColor = Colors.blue;
const kAppName = "AutoNet Config";